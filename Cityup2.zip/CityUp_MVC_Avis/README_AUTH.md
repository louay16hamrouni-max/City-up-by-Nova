# CityUp — Atelier Sessions et Sécurité PHP

## Installation (XAMPP / WAMP / PHP + MySQL)
1. Copier le dossier `CityUp_MVC_Avis` dans `htdocs` (ou le dossier web local).
2. Démarrer Apache et MySQL et ouvrir `http://localhost/phpmyadmin`.
3. Importer `database/schema.sql` (crée la base `cityup` et la table `users`).
4. Par défaut, la connexion utilise 127.0.0.1 / base cityup / utilisateur root / mot de passe vide.
   Pour modifier les identifiants, définir les variables d'environnement `CITYUP_DB_HOST`, `CITYUP_DB_NAME`, `CITYUP_DB_USER`, `CITYUP_DB_PASSWORD`.
5. Ouvrir `http://localhost/CityUp_MVC_Avis/index.php?page=register`, puis créer un compte.
6. Se connecter à `index.php?page=login`. Un compte public reçoit toujours le rôle `user`.
7. Pour tester le backoffice, promouvoir **un compte de confiance** avec cette commande dans phpMyAdmin :
   `UPDATE users SET role='admin' WHERE email='votre-adresse@example.com';`
   Se déconnecter puis se reconnecter ; ouvrir `index.php?page=dashboard`.

## Architecture MVC
- `app/Models/UserModel.php` : entité User (attributs privés, getters/setters).
- `app/Controllers/AuthController.php` : PDO, validation, registration, login, authorization, logout.
- `app/Views/pages/login.php`, `register.php`, `account.php` : affichage uniquement.
- `index.php` / `app/routes.php` : point d'entrée et routage.
- `config/database.php` : connexion PDO Singleton.

## Sécurité
- `password_hash` et `password_verify`; requêtes préparées PDO.
- `session_regenerate_id(true)` après login; expiration après 30 minutes d'inactivité.
- Cookies `HttpOnly`, `SameSite=Lax`, `Secure` si HTTPS.
- Contrôle des rôles avant l'accès aux pages/actions admin; CSRF sur les formulaires POST.
- Sorties HTML échappées avec `h()`.

## Remarque
Les avis restent stockés dans `storage/reviews.json`, comme dans le projet de départ. Les nouveaux avis sont liés aux comptes par un identifiant `user:<id>`. Les anciens avis anonymes ne sont pas transférés automatiquement.
Pour la production : configurer HTTPS, protéger les identifiants MySQL, interdire l'accès public à `storage/`, limiter le nombre de tentatives de connexion, et prévoir une politique de réinitialisation de mot de passe.

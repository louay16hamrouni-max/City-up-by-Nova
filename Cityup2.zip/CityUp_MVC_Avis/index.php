<?php
declare(strict_types=1);
ini_set('session.use_strict_mode','1');
ini_set('session.cookie_httponly','1');
ini_set('session.cookie_samesite','Lax');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ini_set('session.cookie_secure','1');
session_start();
if (isset($_SESSION['last_activity']) && time()-(int)$_SESSION['last_activity']>1800) {
 $_SESSION=[];session_destroy();session_start();
}
$_SESSION['last_activity']=time();
require __DIR__.'/app/helpers.php';
require __DIR__.'/config/database.php';
require __DIR__.'/app/Controllers/Controller.php';
require __DIR__.'/app/Controllers/HomeController.php';
require __DIR__.'/app/Models/Review.php';
require __DIR__.'/app/Models/UserModel.php';
require __DIR__.'/app/Controllers/ReviewController.php';
require __DIR__.'/app/Controllers/AuthController.php';
require __DIR__.'/app/Controllers/ModuleController.php';
require __DIR__.'/app/Controllers/PasswordResetController.php';
require __DIR__.'/app/Controllers/UserController.php';
// Aggregate-only users counter, available only to authenticated administrators.
if (($_GET['page'] ?? '') === 'users-count') {
 AuthController::requireRole('admin');
 header('Content-Type: application/json; charset=utf-8');
 header('Cache-Control: no-store, no-cache, must-revalidate');
 try {
  $count=(int) Database::getConnexion()->query('SELECT COUNT(*) FROM users')->fetchColumn();
  echo json_encode(['ok'=>true,'count'=>$count]);
 } catch (PDOException $e) {
  http_response_code(503);
  echo json_encode(['ok'=>false,'count'=>null]);
 }
 exit;
}
$routes=require __DIR__.'/app/routes.php';
$page=(string)($_GET['page']??'home');
if (!isset($routes[$page])) {http_response_code(404);exit('404 | Page not found');}
if (in_array($page,['review-save','review-delete','review-moderate','target-add','logout'],true)&&$_SERVER['REQUEST_METHOD']!=='POST') {
 http_response_code(405);header('Allow: POST');exit('Method not allowed');
}
if (in_array($page,['dashboard','moderation','review-moderate','target-add','users-admin'],true)) AuthController::requireRole('admin');
if (in_array($page,['review-save','review-delete','account','profile','preferences','favorites','suggestions'],true)) AuthController::requireAuth();
[$class,$method]=$routes[$page];
try {(new $class())->$method();}
catch(PDOException $e) {http_response_code(503);exit('Database connection failed. Configure MySQL and import database/schema.sql.');}

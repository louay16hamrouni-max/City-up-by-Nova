# City Up — Templates modulaires

## Nouveaux écrans

- `index.php?page=modules` : catalogue Front Office des 7 modules.
- `index.php?page=modules&module=mobility` : détails d’un module (exemple).
- `index.php?page=modules&area=admin` : catalogue Back Office, réservé à l’admin.
- `index.php?page=modules&module=finance&area=admin` : détails du module dans Back Office.

Les templates correspondent au PDF UrbanPulse (4).pdf et au schéma City Up, incluant les modules Reviews & Ratings, Premium Membership & Finance, Smart Mobility & Transport.

## Ce qui fonctionne
Navigation, recherche dans les modules, interface responsive, routes MVC et contrôle d’accès admin. Les avis utilisent toujours le contrôleur et les pages existants.

## Ce qui reste à développer
Les autres modules affichent des templates de fonctionnalités et des entités, **pas** des CRUD connectés à MySQL. Ajouter Models, Controllers, tables SQL et validation avant toute opération métier réelle (réservation, paiement, transport, etc.).

## Lancer
Extraire dans `C:\xampp\htdocs\CityUp_MVC_Avis`, démarrer Apache + MySQL, importer `database/schema.sql` et ouvrir `http://localhost/CityUp_MVC_Avis/index.php?page=modules`.

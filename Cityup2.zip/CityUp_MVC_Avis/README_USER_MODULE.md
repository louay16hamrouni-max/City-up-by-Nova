# City Up — User & Personalization Management

## Pages available
- `index.php?page=home` — homepage focused on user module
- `index.php?page=modules` — user module overview
- `index.php?page=register` and `index.php?page=login`
- `index.php?page=account` — account
- `index.php?page=profile` — change username/email/password
- `index.php?page=preferences` — interests, city, language
- `index.php?page=favorites` — add and remove favorites
- `index.php?page=suggestions` — category-based discovery ideas (not live recommendations)
- `index.php?page=users-admin` — admin role management (admins only)

## XAMPP setup
1. Place `CityUp_MVC_Avis` inside `C:\xampp\htdocs\City UP\`.
2. Start Apache and MySQL via XAMPP.
3. In phpMyAdmin, import `database/user_module.sql` to create/extend the `cityup` database.
4. Open `http://localhost/City%20UP/CityUp_MVC_Avis/index.php?page=modules`.
5. Register, log in and test editing preferences and favorites.
6. For an administrator, manually promote a trusted registered account using phpMyAdmin: `UPDATE users SET role='admin' WHERE email='your-real-email@example.com';` then sign out and in again.

## Notes
- The old reviews, transport, finance and other module source files are preserved for future work, but are **not linked or routed** in this user-only build.
- Suggestions are illustrative category-based prompts; they do not query real city listings.
- CSRF tokens, password hashing and prepared PDO statements are used.
- No changes made to existing user data: schema uses CREATE TABLE IF NOT EXISTS.

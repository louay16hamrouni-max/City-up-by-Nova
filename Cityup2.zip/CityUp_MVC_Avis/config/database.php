<?php
declare(strict_types=1);
final class Database {
    private static ?PDO $pdo = null;
    public static function getConnexion(): PDO {
        if (self::$pdo === null) {
            $host = getenv('CITYUP_DB_HOST') ?: '127.0.0.1';
            $name = getenv('CITYUP_DB_NAME') ?: 'cityup';
            $user = getenv('CITYUP_DB_USER') ?: 'root';
            $pass = getenv('CITYUP_DB_PASSWORD') ?: '';
            self::$pdo = new PDO('mysql:host='.$host.';dbname='.$name.';charset=utf8mb4', $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        }
        return self::$pdo;
    }
}

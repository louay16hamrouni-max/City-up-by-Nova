# City Up — compteur Users réel

Le Dashboard conserve son apparence d’origine, mais est désormais accessible UNIQUEMENT aux comptes qui possèdent le rôle admin dans la table users. Le compteur Users affiche le nombre de lignes de la table `users` de la base `cityup` (requête `SELECT COUNT(*) FROM users`). Il se rafraîchit automatiquement toutes les 10 secondes tant que l’onglet est visible, ainsi qu’au retour sur l’onglet.

## Installation XAMPP
1. Arrêter Apache avant de remplacer les fichiers si nécessaire.
2. Copier le dossier `CityUp_MVC_Avis` dans `C:\xampp\htdocs\City UP\`.
3. Vérifier la configuration `config/database.php` (base `cityup`, utilisateur `root`, mot de passe local).
4. Démarrer Apache et MySQL et importer `database/schema.sql` si la table `users` n’existe pas. NE PAS supprimer ni réinitialiser la base existante.
5. Créer un compte via `index.php?page=register` (le rôle par défaut est `user`).
6. Se connecter avec un compte admin autorisé, puis aller sur `index.php?page=dashboard`. Le compteur affiche le nombre total des comptes inscrits. Un utilisateur normal reçoit HTTP 403.

Si le compteur affiche un tiret « — », la connexion MySQL ne fonctionne pas ou la table `users` manque. Si le compteur affiche 0, contrôler dans phpMyAdmin que le compte est réellement dans la table `cityup.users` et que le site utilise bien cette base.

Ce compteur est un total global, pas le nombre de personnes connectées.

# Dashboard CityUp — accès réservé aux admins

Le Dashboard n’est plus public ou en libre accès. Le compte doit être connecté avec le rôle **admin** dans MySQL. Le compteur Users lit `SELECT COUNT(*) FROM users` et se rafraîchit automatiquement. Les autres cartes d’activité utilisent encore des valeurs de démonstration.

Le lien `index.php?page=dashboard`, l’endpoint JSON `index.php?page=users-count`, la modération et la gestion des utilisateurs sont soumis à un contrôle de rôle côté serveur.

Un utilisateur standard peut s’inscrire et accéder à My Account, Profile, Preferences, Favorites et Suggestions, mais reçoit HTTP 403 s’il tente de consulter le Back Office.

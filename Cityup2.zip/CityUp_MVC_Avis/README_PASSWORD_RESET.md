# CITY UP — Forgot Password / New Password

## Added pages
- `index.php?page=forgot-password` : enter account email.
- `index.php?page=reset-password&token=...` : enter and confirm a new password.
- Link “Forgot password?” is included on Login page.

## Required database step
In phpMyAdmin select the `cityup` database, then import `database/password_reset_only.sql`. If installing the entire app fresh, import `database/user_module.sql` instead.

## Local XAMPP test without email service
1. Configure the environment variable `CITYUP_DEV_RESET_LINK=1` in Apache's environment (e.g. add `SetEnv CITYUP_DEV_RESET_LINK 1` to XAMPP's Apache config and restart Apache). For PHP on Apache, `getenv` reads this variable.
2. Visit `http://localhost/City%20UP/CityUp_MVC_Avis/index.php?page=forgot-password`.
3. Submit the email of an existing registered user. In development mode, an on-screen reset link appears.
4. Click the link, type New Password + Confirm New Password, then log in.
5. **Never enable this development option on a public server**; it exposes reset links to whoever can request them on localhost.

## Real email delivery
The code calls PHP `mail()`, which requires a configured email sending service and usually does not work with vanilla XAMPP. For production, use a reputable SMTP delivery provider, authenticated sender/domain, HTTPS, and turn OFF `CITYUP_DEV_RESET_LINK`. Successful email delivery has not been verified in this environment.

## Security notes
- 32 random bytes, SHA-256 token stored in database, 30-min expiry, one-time use.
- Password hashed with `password_hash` and compared later with `password_verify`.
- Generic submission message prevents easy email enumeration.
- Per-account one-minute request throttling (for production add IP-level controls).
- CSRF protection on forms; reset tokens never in logs intentionally, but standard web servers may log reset URLs.
- Password changes do not automatically terminate existing PHP sessions on other devices: add server-side session versioning if deployment requires it.

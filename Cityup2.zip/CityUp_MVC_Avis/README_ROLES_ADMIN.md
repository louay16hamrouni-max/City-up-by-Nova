# City Up — rôles User / Admin (XAMPP)

## Comportement
- Toute inscription sur `index.php?page=register` crée un utilisateur avec le rôle `user` (forcé par le serveur).
- Login User → `index.php?page=account`.
- Login Admin → `index.php?page=dashboard`.
- Le Dashboard, le compteur Users, la modération et la gestion des utilisateurs vérifient le rôle enregistré en base de données. Un utilisateur connecté avec le rôle `user` reçoit une erreur 403 sur les URL d’administration, même s’il les connaît.
- La page Back Office / Users mène désormais à `index.php?page=users-admin` pour gérer les comptes. Seul un admin peut promouvoir/rétrograder un utilisateur.

## Activer le tout premier admin (propriétaire du site uniquement)
1. Démarrer Apache + MySQL dans XAMPP et conserver la base existante `cityup` ainsi que ses comptes. **Ne réimporter aucun SQL et ne supprimer aucune table.**
2. Créer son propre compte via le site (en tant que User).
3. Dans phpMyAdmin, choisir la base `cityup`, table `users` → Parcourir → Modifier sur **son propre compte** → dans la colonne `role`, choisir `admin` → Exécuter. Ne modifier que les comptes de confiance.
4. Se déconnecter puis se reconnecter. La connexion admin ouvre automatiquement le Dashboard.

## Tester
- Inscrire un nouveau compte → vérifier `role=user` dans phpMyAdmin et la redirection vers My Account après Login.
- Tenter manuellement `http://localhost/City%20UP/CityUp_MVC_Avis/index.php?page=dashboard` avec ce compte → accès refusé (403).
- Se connecter avec le compte admin → Dashboard, compteur Users et User Management disponibles.
- Le compteur Users correspond au nombre total de comptes en base, y compris admins.

Conserve le même chemin local du projet : `C:\xampp\htdocs\City UP\CityUp_MVC_Avis`.

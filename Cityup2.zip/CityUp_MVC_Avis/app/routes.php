<?php
return [
 'forgot-password'=>[PasswordResetController::class,'forgot'],
 'reset-password'=>[PasswordResetController::class,'reset'],
 'profile'=>[UserController::class,'profile'],
 'preferences'=>[UserController::class,'preferences'],
 'favorites'=>[UserController::class,'favorites'],
 'suggestions'=>[UserController::class,'suggestions'],
 'users-admin'=>[UserController::class,'adminUsers'],

 'modules'=>[ModuleController::class,'index'],
 'home'=>[HomeController::class,'index'],'dashboard'=>[HomeController::class,'dashboard'],
 'reviews'=>[ReviewController::class,'index'],'review-save'=>[ReviewController::class,'save'],
 'review-delete'=>[ReviewController::class,'remove'],'moderation'=>[ReviewController::class,'admin'],
 'review-moderate'=>[ReviewController::class,'moderate'],'target-add'=>[ReviewController::class,'addTarget'],
 'register'=>[AuthController::class,'register'],'login'=>[AuthController::class,'login'],
 'logout'=>[AuthController::class,'logout'],'account'=>[AuthController::class,'account']
];

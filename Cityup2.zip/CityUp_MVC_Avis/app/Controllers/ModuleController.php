<?php
class ModuleController extends Controller {
 public static function modules(): array {
 return [
  'users'=>['title'=>'User & Personalization','icon'=>'fa-users','description'=>'Manage your profile, preferences and favorites.','features'=>['Register','Log in','Update profile','Manage preferences','Manage favorites','View personalized suggestions'],'entities'=>['User','Preference','UserPreferences','Favorite']],
  'business'=>['title'=>'Local Businesses & Urban Services','icon'=>'fa-store','description'=>'Discover businesses, services and local offers.','features'=>['Register business','Update business','Publish offers','Manage urban services','View business details','Approve businesses'],'entities'=>['Business','BusinessType','City','Offer','Service']],
  'events'=>['title'=>'Events & Activities','icon'=>'fa-calendar-days','description'=>'Discover city events and manage reservations.','features'=>['Browse events','Make reservation','Cancel reservation','View bookings','Create event','Manage activities'],'entities'=>['Event','Activity','Reservation']],
  'finance'=>['title'=>'Premium Membership & Finance','icon'=>'fa-wallet','description'=>'Subscription plans, payments and invoices.','features'=>['Compare subscription plans','Subscribe to a plan','Manage subscription','Choose payment method','View payments','Download invoices'],'entities'=>['SubscriptionPlan','Subscription','Payment','PaymentMethod','Invoice','Wallet']],
  'reviews'=>['title'=>'Reviews & Ratings','icon'=>'fa-star','description'=>'Share reviews and discover community ratings.','features'=>['Add review','Edit review','Delete review','View review','Calculate average rating','Moderate reviews'],'entities'=>['Avis','Comment','User','Business','Place']],
  'mobility'=>['title'=>'Smart Mobility & Transport','icon'=>'fa-bus','description'=>'Explore buses, taxis, louages, routes and parking.','features'=>['Find transport','Browse transport routes','Check schedules','Compare fares','Check parking','Manage mobility bookings'],'entities'=>['Transport','TransportRoute','Transportation','Parking','MobilityBooking','User']],
 ];
 }
 public function index(): void {
  $key = (string)($_GET['module'] ?? '');
  $modules = self::modules();
  if ($key !== '' && !isset($modules[$key])) {http_response_code(404);exit('Module not found');}
  $admin = ($_GET['area'] ?? '') === 'admin';
  if ($admin) AuthController::requireRole('admin');
  $this->render('modules',['title'=>'City Up | '.($key ? $modules[$key]['title'] : 'All Modules'), 'currentPage'=>'modules','modules'=>$modules,'selected'=>$key,'adminArea'=>$admin],$admin);
 }
}
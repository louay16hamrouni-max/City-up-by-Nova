<?php
declare(strict_types=1);
class AuthController extends Controller {
 private PDO $db;
 public function __construct() { $this->db=Database::getConnexion(); }
 public static function isAuthenticated(): bool { return isset($_SESSION['user_id']) && (int)$_SESSION['user_id']>0; }
 public static function requireAuth(): void {
  if (!self::isAuthenticated()) redirectTo('login');
 }
 public static function requireRole(string $role): void {
  self::requireAuth();
  // Authorization is verified against the database on every protected request.
  // Session data alone must never grant administrator permissions.
  try {
   $q=Database::getConnexion()->prepare('SELECT role FROM users WHERE id=:id LIMIT 1');
   $q->execute(['id'=>(int)$_SESSION['user_id']]);
   $currentRole=$q->fetchColumn();
  } catch (PDOException $e) {
   http_response_code(503);
   exit('Database unavailable. Please start MySQL.');
  }
  if ($currentRole===false) {
   $_SESSION=[];
   session_regenerate_id(true);
   redirectTo('login');
  }
  $_SESSION['role']=(string)$currentRole;
  if ($currentRole!==$role) {
   http_response_code(403);
   header('Content-Type: text/html; charset=utf-8');
   exit('<!doctype html><html lang="en"><meta charset="utf-8"><title>Access denied | CityUp</title><body style="font-family:Arial,sans-serif;max-width:520px;margin:14vh auto;padding:24px;color:#153452"><h1>Access denied (403)</h1><p>The Dashboard is reserved for administrators.</p><p><a href="index.php?page=account">Back to My Account</a> · <a href="index.php?page=home">City Up Home</a></p></body></html>');
  }
 }
 public function register(): void {
  if (self::isAuthenticated()) redirectTo('account');
  $errors=[];$old=[];
  if ($_SERVER['REQUEST_METHOD']==='POST') {
   verifyCsrf();$old=['username'=>trim((string)($_POST['username']??'')),'email'=>trim((string)($_POST['email']??''))];
   $password=(string)($_POST['password']??'');$confirm=(string)($_POST['password_confirm']??'');
   if (!preg_match('/^[a-zA-Z0-9_-]{3,50}$/D',$old['username'])) $errors[]='Username: 3–50 letters, numbers, _ or -.';
   if (!filter_var($old['email'],FILTER_VALIDATE_EMAIL)||strlen($old['email'])>150) $errors[]='Enter a valid email.';
   if (strlen($password)<8) $errors[]='Password: minimum 8 characters.';
   if ($password!==$confirm) $errors[]='Passwords do not match.';
   if (!$errors) {
    $q=$this->db->prepare('SELECT id FROM users WHERE email=:email OR username=:username LIMIT 1');
    $q->execute(['email'=>$old['email'],'username'=>$old['username']]);
    if ($q->fetch()) $errors[]='Email or username already used.';
    else {
     $q=$this->db->prepare("INSERT INTO users(username,email,password,role) VALUES(:username,:email,:password,'user')");
     try {$q->execute(['username'=>$old['username'],'email'=>$old['email'],'password'=>password_hash($password,PASSWORD_DEFAULT)]);}
     catch (PDOException $e) {$errors[]='Unable to create account. Check your details.';}
     if (!$errors) redirectTo('login',['registered'=>1]);
    }
   }
  }
  $this->render('register',compact('errors','old')+['title'=>'CityUp | Register']);
 }
 public function login(): void {
  if (self::isAuthenticated()) redirectTo(($_SESSION['role']??'')==='admin'?'dashboard':'account');
  $errors=[];
  if ($_SERVER['REQUEST_METHOD']==='POST') {
   verifyCsrf();$email=trim((string)($_POST['email']??''));$password=(string)($_POST['password']??'');
   $q=$this->db->prepare('SELECT * FROM users WHERE email=:email LIMIT 1');$q->execute(['email'=>$email]);$row=$q->fetch();
   if (!$row||!password_verify($password,(string)$row['password'])) $errors[]='Incorrect email or password.';
   else {
    session_regenerate_id(true);$_SESSION['user_id']=(int)$row['id'];
    $_SESSION['username']=(string)$row['username'];$_SESSION['role']=(string)$row['role'];
    $_SESSION['last_activity']=time();unset($_SESSION['csrf']);
    redirectTo($row['role']==='admin'?'dashboard':'account');
   }
  }
  $this->render('login',compact('errors')+['title'=>'CityUp | Login']);
 }
 public function account(): void {
  self::requireAuth();
  $q=$this->db->prepare('SELECT * FROM users WHERE id=:id LIMIT 1');$q->execute(['id'=>(int)$_SESSION['user_id']]);
  $row=$q->fetch();if (!$row){$this->logoutSession();redirectTo('login');}
  $_SESSION['role']=$row['role'];$_SESSION['username']=$row['username'];
  $user=UserModel::fromArray($row);
  $this->render('account',compact('user')+['title'=>'CityUp | My Account']);
 }
 private function logoutSession(): void {
  $_SESSION=[];
  if (ini_get('session.use_cookies')) {
   $p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
  }
  session_destroy();
 }
 public function logout(): void {verifyCsrf();$this->logoutSession();redirectTo('login');}
}

<?php
declare(strict_types=1);
class UserController extends Controller {
 private PDO $db;
 private const CATEGORIES=['Restaurants','Cafes','Culture','Events','Shopping','Nature','Transport'];
 public function __construct(){ $this->db=Database::getConnexion(); }
 private function user(): array {
  AuthController::requireAuth();
  $q=$this->db->prepare('SELECT id,username,email,role,created_at FROM users WHERE id=:id');
  $q->execute(['id'=>(int)$_SESSION['user_id']]);$u=$q->fetch();
  if (!$u){http_response_code(401);exit('Account no longer exists. Log out and sign in again.');}
  return $u;
 }
 private function renderPage(string $name,array $data=[]):void {
  $this->render($name,$data+['title'=>'City Up | User & Personalization','currentPage'=>'user']);
 }
 public function profile():void {
  $u=$this->user();$errors=[];$success=isset($_GET['saved']);
  if($_SERVER['REQUEST_METHOD']==='POST'){
   verifyCsrf();$username=trim((string)($_POST['username']??''));$email=trim((string)($_POST['email']??''));
   $new=(string)($_POST['new_password']??'');$current=(string)($_POST['current_password']??'');
   if(!preg_match('/^[a-zA-Z0-9_-]{3,50}$/D',$username))$errors[]='Username: 3–50 letters, numbers, _ or -.';
   if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>150)$errors[]='Please provide a valid email.';
   if($new!=='' && strlen($new)<8)$errors[]='New password must have at least 8 characters.';
   if($new!=='' && $current==='')$errors[]='Enter your current password to change it.';
   if($new!==''){
    $q=$this->db->prepare('SELECT password FROM users WHERE id=?');$q->execute([$u['id']]);
    if(!password_verify($current,(string)$q->fetchColumn()))$errors[]='Current password is incorrect.';
   }
   $q=$this->db->prepare('SELECT id FROM users WHERE (username=:n OR email=:e) AND id<>:id LIMIT 1');
   $q->execute(['n'=>$username,'e'=>$email,'id'=>$u['id']]);
   if($q->fetch())$errors[]='Email or username is already taken.';
   if(!$errors){
    if($new!==''){$q=$this->db->prepare('UPDATE users SET username=?,email=?,password=? WHERE id=?');$q->execute([$username,$email,password_hash($new,PASSWORD_DEFAULT),$u['id']]);}
    else {$q=$this->db->prepare('UPDATE users SET username=?,email=? WHERE id=?');$q->execute([$username,$email,$u['id']]);}
    $_SESSION['username']=$username;redirectTo('profile',['saved'=>1]);
   }
   $u['username']=$username;$u['email']=$email;
  }
  $this->renderPage('user_profile',compact('u','errors','success'));
 }
 public function preferences():void {
  $u=$this->user();$errors=[];
  if($_SERVER['REQUEST_METHOD']==='POST'){
   verifyCsrf();$cats=(array)($_POST['categories']??[]);
   $cats=array_values(array_intersect(self::CATEGORIES,array_filter($cats,'is_string')));
   $city=trim((string)($_POST['city']??''));$lang=(string)($_POST['language']??'en');
   if($city===''||mb_strlen($city)>100)$errors[]='City is required (max. 100 characters).';
   if(!in_array($lang,['en','fr','ar'],true))$errors[]='Unsupported language.';
   if(!$errors){
    $q=$this->db->prepare('INSERT INTO user_preferences(user_id,categories,city,language) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE categories=VALUES(categories),city=VALUES(city),language=VALUES(language)');
    $q->execute([$u['id'],implode(',',$cats),$city,$lang]);redirectTo('preferences',['saved'=>1]);
   }
  }
  $q=$this->db->prepare('SELECT * FROM user_preferences WHERE user_id=?');$q->execute([$u['id']]);
  $pref=$q->fetch()?:['categories'=>'','city'=>'Tunis','language'=>'en'];
  if($_SERVER['REQUEST_METHOD']==='POST')$pref=['categories'=>implode(',',array_intersect(self::CATEGORIES,(array)($_POST['categories']??[]))),'city'=>(string)($_POST['city']??''),'language'=>(string)($_POST['language']??'en')];
  $selected=explode(',',(string)$pref['categories']);$categories=self::CATEGORIES;$success=isset($_GET['saved']);
  $this->renderPage('user_preferences',compact('pref','selected','categories','errors','success'));
 }
 public function favorites():void {
  $u=$this->user();$errors=[];
  if($_SERVER['REQUEST_METHOD']==='POST'){
   verifyCsrf();$action=(string)($_POST['action']??'');
   if($action==='add'){
    $name=trim((string)($_POST['place_name']??''));$type=(string)($_POST['place_type']??'Place');
    if($name===''||mb_strlen($name)>120)$errors[]='Name is required (max. 120 characters).';
    if(!in_array($type,['Place','Business','Event','Activity'],true))$errors[]='Invalid category.';
    if(!$errors){$q=$this->db->prepare('INSERT INTO favorites(user_id,place_name,place_type) VALUES(?,?,?)');$q->execute([$u['id'],$name,$type]);redirectTo('favorites',['saved'=>1]);}
   }elseif($action==='delete'){
    $id=filter_var($_POST['id']??null,FILTER_VALIDATE_INT);
    if($id){$q=$this->db->prepare('DELETE FROM favorites WHERE id=? AND user_id=?');$q->execute([$id,$u['id']]);}redirectTo('favorites');
   }
  }
  $q=$this->db->prepare('SELECT id,place_name,place_type,created_at FROM favorites WHERE user_id=? ORDER BY id DESC');
  $q->execute([$u['id']]);$favorites=$q->fetchAll();$success=isset($_GET['saved']);
  $this->renderPage('user_favorites',compact('favorites','errors','success'));
 }
 public function suggestions():void {
  $u=$this->user();
  $q=$this->db->prepare('SELECT categories,city FROM user_preferences WHERE user_id=?');$q->execute([$u['id']]);
  $pref=$q->fetch()?:['categories'=>'','city'=>'Tunis'];$cats=array_filter(explode(',',(string)$pref['categories']));
  $items=[
   'Restaurants'=>['Explore local restaurants','Find restaurants and food spots in your preferred city.'],
   'Cafes'=>['Find cafés','Explore cafés and places to meet friends.'],
   'Culture'=>['Discover cultural places','Museums, monuments and cultural experiences.'],
   'Events'=>['See events','Look for upcoming events and activities.'],
   'Shopping'=>['Local shopping','Discover neighborhood shops and markets.'],
   'Nature'=>['Outdoor places','Explore parks and outdoor spaces.'],
   'Transport'=>['Plan mobility','Explore public transport and mobility options.']
  ];
  $suggestions=[];foreach($cats as $cat){if(isset($items[$cat]))$suggestions[]=['category'=>$cat,'title'=>$items[$cat][0],'description'=>$items[$cat][1]];}
  $this->renderPage('user_suggestions',compact('suggestions','pref'));
 }
 public function adminUsers():void {
  AuthController::requireRole('admin');$errors=[];
  if($_SERVER['REQUEST_METHOD']==='POST'){
   verifyCsrf();$id=filter_var($_POST['id']??null,FILTER_VALIDATE_INT);$role=(string)($_POST['role']??'');
   if(!$id||!in_array($role,['user','admin'],true))$errors[]='Invalid request.';
   elseif($id===(int)$_SESSION['user_id'] && $role!=='admin')$errors[]='You cannot remove your own admin role.';
   else{$q=$this->db->prepare('UPDATE users SET role=? WHERE id=?');$q->execute([$role,$id]);redirectTo('users-admin',['saved'=>1]);}
  }
  $users=$this->db->query('SELECT id,username,email,role,created_at FROM users ORDER BY id DESC')->fetchAll();
  $this->render('user_admin',compact('users','errors')+['title'=>'City Up | Users Administration','currentPage'=>'users-admin','success'=>isset($_GET['saved'])],true);
 }
}

<?php
class HomeController extends Controller {
 public function index(): void { $this->render('home',['title'=>'CityUp | Explore Your City','currentPage'=>'home']); }
 public function dashboard(): void {
  // Defense in depth: Dashboard is visible only to authenticated admins.
  AuthController::requireRole('admin');
  $usersCount = null;
  try {
   $db = Database::getConnexion();
   $usersCount = (int) $db->query('SELECT COUNT(*) FROM users')->fetchColumn();
  } catch (PDOException $e) {
   // Do not expose SQL details in the interface.
  }
  $this->render('dashboard',['title'=>'CityUp | Dashboard','currentPage'=>'dashboard','usersCount'=>$usersCount],true);
 }
}

<?php
declare(strict_types=1);
class UserModel {
 private int $id=0;
 private string $username='';
 private string $email='';
 private string $password='';
 private string $role='user';
 private string $createdAt='';
 public function getId(): int { return $this->id; }
 public function getUsername(): string { return $this->username; }
 public function getEmail(): string { return $this->email; }
 public function getPassword(): string { return $this->password; }
 public function getRole(): string { return $this->role; }
 public function getCreatedAt(): string { return $this->createdAt; }
 public function setUsername(string $v): void { $this->username=$v; }
 public function setEmail(string $v): void { $this->email=$v; }
 public function setPassword(string $v): void { $this->password=$v; }
 public function setRole(string $v): void { $this->role=$v; }
 public static function fromArray(array $r): self {
  $u=new self();$u->id=(int)$r['id'];$u->username=(string)$r['username'];
  $u->email=(string)$r['email'];$u->password=(string)$r['password'];
  $u->role=(string)$r['role'];$u->createdAt=(string)($r['created_at']??'');return $u;
 }
}

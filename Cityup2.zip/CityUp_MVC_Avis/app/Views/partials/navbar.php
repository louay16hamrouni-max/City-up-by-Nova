<header class="site-header">
<a class="brand" href="index.php?page=home"><span class="brand-mark"><i class="fa-solid fa-location-dot"></i><small>▥▥▥</small></span><strong>City<span>Up</span></strong></a>
<nav aria-label="Main navigation" class="top-nav">
<a class="<?= $currentPage === "home" ? "active" : "" ?>" href="index.php?page=home">Home</a><a href="index.php?page=home#discover">Explore <i class="fa-solid fa-chevron-down tiny"></i></a><a href="#about">About</a>
<a class="<?= $currentPage === "modules" ? "active" : "" ?>" href="index.php?page=modules">Modules</a><a class="<?= $currentPage === "reviews" ? "active" : "" ?>" href="index.php?page=reviews">Reviews</a><a href="index.php?page=profile">Profile</a><a href="index.php?page=favorites">Favorites</a><a href="index.php?page=suggestions">Suggestions</a><a class="<?= $currentPage === "dashboard" ? "active" : "" ?>" href="index.php?page=dashboard">Back Office</a></nav>
<div class="header-actions"><button aria-label="Search" class="icon-button" onclick="document.querySelector('#main-search').focus()"><i class="fa-solid fa-magnifying-glass"></i></button><?php if (!empty($_SESSION['user_id'])): ?><a class="btn btn-outline" href="index.php?page=account">My Account</a><?php else: ?><a class="btn btn-outline" href="index.php?page=login">Sign In</a><?php endif; ?></div>
<button aria-label="Toggle menu" class="mobile-menu" onclick="document.querySelector('.top-nav').classList.toggle('show')"><i class="fa-solid fa-bars"></i></button>
</header>

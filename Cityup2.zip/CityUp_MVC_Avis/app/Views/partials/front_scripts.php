<script src="public/script.js"></script>

<section class="auth-panel"><h1>Log in to CityUp</h1><p>Access your personal or administrator space.</p>
<?php if (!empty($_GET['registered'])): ?><p class="auth-ok">Account created. Please log in.</p><?php endif; ?>
<?php foreach ($errors as $error): ?><p class="auth-error"><?= h($error) ?></p><?php endforeach; ?>
<form method="post" action="index.php?page=login"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
<label>Email<input required type="email" name="email" autocomplete="email"></label>
<label>Password<input required type="password" name="password" autocomplete="current-password"></label>
<button class="btn btn-primary" type="submit">Log in</button></form>
<p class="auth-links"><a href="index.php?page=forgot-password">Forgot password?</a></p>
<p>New here? <a href="index.php?page=register">Create account</a></p></section>
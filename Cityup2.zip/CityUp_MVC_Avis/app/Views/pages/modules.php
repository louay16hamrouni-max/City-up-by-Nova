<?php
$prefix = 'index.php?page=modules';
$adminSuffix = $adminArea ? '&amp;area=admin' : '';
$heading = $selected ? $modules[$selected]['title'] : 'Explore City Up Modules';
$shown = $selected ? [$selected=>$modules[$selected]] : $modules;
?>
<div class="cu-module-shell <?= $adminArea?'cu-in-admin':'cu-in-front' ?> <?= $selected?'cu-module-detail':'cu-module-overview' ?>">
 <div class="cu-module-hero">
  <div><span class="cu-eyebrow">CITY UP · SMART CITY PLATFORM</span><h1><?= h($heading) ?></h1><p><?= $selected ? h($modules[$selected]['description']) : 'One city. One platform. Explore the services that connect your urban life.' ?></p></div>
  <div class="cu-hero-icon"><i class="fa-solid <?= h($selected ? $modules[$selected]['icon'] : 'fa-city') ?>"></i></div>
 </div>
 <div class="cu-module-bar"><a href="<?= $prefix.$adminSuffix ?>" class="cu-back"><i class="fa-solid fa-layer-group"></i> All modules</a><div class="cu-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" id="cuModuleSearch" placeholder="Search modules and features…" aria-label="Search modules and features"></div></div>
 <div class="cu-module-grid">
 <?php foreach($shown as $key=>$module): ?>
 <article class="cu-module-card" data-module-search="<?= h(strtolower($module['title'].' '.implode(' ',$module['features']).' '.implode(' ',$module['entities']))) ?>">
  <div class="cu-module-card-top"><span class="cu-icon"><i class="fa-solid <?= h($module['icon']) ?>"></i></span><span class="cu-category"><?= $adminArea?'BACK OFFICE':'FRONT OFFICE' ?></span></div>
  <h2><?= h($module['title']) ?></h2><p><?= h($module['description']) ?></p>
  <?php if(!$selected): ?><a class="cu-open" href="<?= $prefix.'&amp;module='.urlencode($key).$adminSuffix ?>">Explore module <i class="fa-solid fa-arrow-right"></i></a><?php else: ?>
   <h3>Features &amp; screens</h3><div class="cu-feature-grid">
   <?php foreach($module['features'] as $i=>$feature): ?><div class="cu-feature"><i class="fa-solid fa-check"></i><span><?= h($feature) ?></span></div><?php endforeach; ?>
   </div><h3>Related entities</h3><div class="cu-tags"><?php foreach($module['entities'] as $entity): ?><span><?= h($entity) ?></span><?php endforeach; ?></div>
   <?php if($key==='reviews'): ?><a class="cu-action" href="index.php?page=<?= $adminArea?'moderation':'reviews' ?>">Open <?= $adminArea?'review moderation':'reviews' ?> <i class="fa-solid fa-arrow-right"></i></a>
   <?php elseif($key==='users'): ?><div class="cu-user-actions"><a class="cu-action" href="index.php?page=account">My account</a> <a class="cu-action" href="index.php?page=profile">Edit profile</a> <a class="cu-action" href="index.php?page=preferences">Preferences</a> <a class="cu-action" href="index.php?page=favorites">Favorites</a> <a class="cu-action" href="index.php?page=suggestions">Suggestions</a> <?php if($adminArea): ?><a class="cu-action" href="index.php?page=users-admin">Manage users</a><?php endif; ?></div>
   <?php else: ?><div class="cu-notice"><i class="fa-solid fa-circle-info"></i> Template ready for database and controller integration. This module is not yet connected to live data.</div><?php endif; ?>
  <?php endif; ?>
 </article>
 <?php endforeach; ?>
 </div>
 <div id="cuNoResults" class="cu-no-results" hidden>No matching modules found.</div>

</div>
<script>
(function(){const input=document.getElementById('cuModuleSearch');if(!input)return;input.addEventListener('input',function(){let visible=0;document.querySelectorAll('.cu-module-card').forEach(card=>{const ok=card.dataset.moduleSearch.includes(this.value.trim().toLowerCase());card.hidden=!ok;if(ok)visible++});document.getElementById('cuNoResults').hidden=visible!==0;});})();
</script>

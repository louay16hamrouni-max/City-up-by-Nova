<section class="auth-panel"><h1>Forgot your password?</h1><p>Enter your CityUp account email. We will send you a reset link.</p>
<?php foreach($errors as $error): ?><p class="auth-error"><?= h($error) ?></p><?php endforeach; ?>
<?php if ($submitted): ?><p class="auth-ok">If this email is registered, a password-reset link has been sent. Check your inbox and spam folder.</p><?php endif; ?>
<?php if ($devLink): ?><div class="reset-dev"><strong>Local XAMPP test mode:</strong><p>Email delivery is not needed for this local test. <a href="<?= h($devLink) ?>">Open your reset link</a></p></div><?php endif; ?>
<form action="index.php?page=forgot-password" method="post"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>"><label>Email address<input type="email" name="email" autocomplete="email" required maxlength="150"></label><button class="btn btn-primary" type="submit">Send reset link</button></form>
<p><a href="index.php?page=login">Back to Login</a></p></section>
<section class="auth-panel"><h1>Create your CityUp account</h1><p>Join CityUp as a member.</p>
<?php foreach ($errors as $error): ?><p class="auth-error"><?= h($error) ?></p><?php endforeach; ?>
<form method="post" action="index.php?page=register"><input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
<label>Username<input required name="username" minlength="3" maxlength="50" value="<?= h($old['username']??'') ?>"></label>
<label>Email<input required type="email" name="email" value="<?= h($old['email']??'') ?>"></label>
<label>Password (8+ characters)<input required minlength="8" type="password" name="password" autocomplete="new-password"></label>
<label>Confirm password<input required minlength="8" type="password" name="password_confirm" autocomplete="new-password"></label>
<button class="btn btn-primary" type="submit">Register</button></form>
<p>Already registered? <a href="index.php?page=login">Log in</a></p></section>
CREATE DATABASE IF NOT EXISTS cityup CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cityup;
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('user','admin') NOT NULL DEFAULT 'user',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
-- After registering an account, grant admin ONLY to a trusted account in phpMyAdmin:
-- UPDATE users SET role='admin' WHERE email='your-admin@example.com';

# City Up — Tous les modules + User & Personalization

Cette version conserve les modules existants (Business, Events, Finance, Reviews, Mobility), sans Smart City Explorer, comme demandé précédemment. Elle ajoute les fonctionnalités User: Register, Login, Profile, Preferences, Favorites, Suggestions, User Management, Forgot Password et Reset Password.

## Installation XAMPP
1. Extraire le dossier `CityUp_MVC_Avis` dans `C:\xampp\htdocs\City UP\` (faire une copie de sauvegarde du dossier existant avant remplacement).
2. Démarrer Apache et MySQL dans XAMPP.
3. Ouvrir `http://localhost/phpmyadmin/` et importer `database/schema.sql` dans une base `cityup` (ou importer depuis l'onglet SQL; le fichier contient CREATE DATABASE et USE).
4. Importer ensuite `database/user_module.sql` dans phpMyAdmin (ajoute les tables de préférences, favoris et tokens de réinitialisation; conserve les utilisateurs existants).
5. Vérifier `config/database.php` : base `cityup`, utilisateur `root`, mot de passe vide pour XAMPP par défaut. Adapter si vos identifiants MySQL sont différents.
6. Ouvrir `http://localhost/City%20UP/CityUp_MVC_Avis/index.php?page=modules`.

**Attention** : la fonction d'envoi de mail réel du mot de passe oublié nécessite un service SMTP; voir `README_PASSWORD_RESET.md` pour les tests locaux. Certains autres modules sont des templates non connectés aux données, comme auparavant.

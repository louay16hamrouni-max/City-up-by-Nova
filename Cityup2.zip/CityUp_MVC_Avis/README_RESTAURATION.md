CITY UP — Interface originale restauree + fonctionnalites User

- Design original Home restaure (hero, Discover Nearby, cartes, plan).
- Toutes les cartes de modules conservees (Business, Events, Services, Finance, Reviews, Mobility, User).
- Business / Events / Services sont retires uniquement des liens de navigation du haut.
- Get Started retire du haut.
- Back Office et sidebar administrative conserves (acces admin); lien Back Office en haut pour admin et Admin Dashboard en bas de la page Home.
- User: profil, preferences, favoris, suggestions, inscription, connexion, reset du mot de passe conserves.
- Defilement vertical autorise, horizontal bloque.

INSTALLATION
1. Copier le dossier CityUp_MVC_Avis dans C:\xampp\htdocs\City UP\
2. Lancer Apache et MySQL via XAMPP.
3. Si base absente, importer database/schema.sql puis database/user_module.sql et database/password_reset_only.sql selon le README.
4. Ouvrir http://localhost/City%20UP/CityUp_MVC_Avis/ et actualiser Ctrl+F5.
Note: fonctionnement MySQL a tester localement.

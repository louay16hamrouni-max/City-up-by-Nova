<?php
declare(strict_types=1);

 
final class GmailResetMailer {
 public static function send(string $to, string $subject, string $body): void {
  $config = require __DIR__.'/../../config/gmail.local.php';
  $user = trim($config['email']); $pass = preg_replace('/\s+/', '', $config['app_password']);
  if (!filter_var($user, FILTER_VALIDATE_EMAIL) || !filter_var($to, FILTER_VALIDATE_EMAIL) || strlen($pass)!==16) {
   throw new RuntimeException('Configure the Gmail address and 16-character app password.');
  }
  $ctx = stream_context_create(['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>'smtp.gmail.com','allow_self_signed'=>false]]);
  $socket = stream_socket_client('tcp://smtp.gmail.com:587', $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
  if (!$socket) throw new RuntimeException('Could not connect to Gmail SMTP.');
  stream_set_timeout($socket, 15);
  try {
   self::expect($socket, [220]);
   self::command($socket, 'EHLO localhost', [250]);
   self::command($socket, 'STARTTLS', [220]);
   if (stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)!==true) throw new RuntimeException('SMTP TLS negotiation failed.');
   self::command($socket, 'EHLO localhost', [250]);
   self::command($socket, 'AUTH LOGIN', [334]);
   self::command($socket, base64_encode($user), [334]);
   self::command($socket, base64_encode($pass), [235]);
   self::command($socket, 'MAIL FROM:<'.$user.'>', [250]);
   self::command($socket, 'RCPT TO:<'.$to.'>', [250,251]);
   self::command($socket, 'DATA', [354]);
   $headers = ['Date: '.date(DATE_RFC2822),'From: CityUp <'.$user.'>','To: <'.$to.'>','Subject: '.$subject,'MIME-Version: 1.0','Content-Type: text/plain; charset=UTF-8','Content-Transfer-Encoding: base64'];
   self::command($socket, implode("\r\n",$headers)."\r\n\r\n".rtrim(chunk_split(base64_encode($body),76,"\r\n"))."\r\n.", [250]);
    
   @fwrite($socket, "QUIT\r\n");
  } finally { fclose($socket); }
 }
 private static function command($socket, string $line, array $codes): void {
  $data=$line."\r\n";
  while ($data!=='') { $n=fwrite($socket,$data); if (!$n) throw new RuntimeException('SMTP write failed.'); $data=substr($data,$n); }
  self::expect($socket,$codes);
 }
 private static function expect($socket, array $codes): void {
  do { $line=fgets($socket, 4096); if ($line===false || !preg_match('/^\d{3}[ -]/',$line)) throw new RuntimeException('SMTP response missing or invalid.'); } while ($line[3]==='-');
  $code=(int)substr($line,0,3);
  if (!in_array($code,$codes,true)) throw new RuntimeException('Gmail SMTP rejected a request (code '.$code.').');
 }
}

<?php
declare(strict_types=1);

final class PasswordResetController extends Controller {
 private PDO $db;
 public function __construct() { $this->db=Database::getConnexion(); }

 public function forgot(): void {
  $errors=[]; $submitted=false; $devLink=null;
  if ($_SERVER['REQUEST_METHOD']==='POST') {
   verifyCsrf();
   $email=trim((string)($_POST['email']??''));
   if (!filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($email)>150) $errors[]='Please enter a valid email address.';
   else {
    $submitted=true;
     
    $q=$this->db->prepare('SELECT id FROM users WHERE email=:email LIMIT 1');
    $q->execute(['email'=>$email]); $user=$q->fetch();
    if ($user) {
      
     $q=$this->db->prepare('SELECT id FROM password_resets WHERE user_id=:uid AND created_at > DATE_SUB(NOW(), INTERVAL 60 SECOND) LIMIT 1');
     $q->execute(['uid'=>(int)$user['id']]);
     if (!$q->fetch()) {
      $token=bin2hex(random_bytes(32)); $hash=hash('sha256',$token);
      $this->db->beginTransaction();
      try {
       $q=$this->db->prepare('DELETE FROM password_resets WHERE user_id=:uid');
       $q->execute(['uid'=>(int)$user['id']]);
       $q=$this->db->prepare('INSERT INTO password_resets (user_id,token_hash,expires_at) VALUES (:uid,:hash,DATE_ADD(NOW(), INTERVAL 30 MINUTE))');
       $q->execute(['uid'=>(int)$user['id'],'hash'=>$hash]);
       $this->db->commit();
      } catch (Throwable $e) { $this->db->rollBack(); throw $e; }
      $host=$_SERVER['HTTP_HOST']??'localhost';
      $host=preg_match('/^[a-zA-Z0-9.:-]+$/D',$host)?$host:'localhost';
      $https=!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
      $base=($https?'https':'http').'://'.$host.rtrim(dirname($_SERVER['SCRIPT_NAME']??'/'),'/\\');
      $url=$base.'/index.php?page=reset-password&token='.rawurlencode($token);
       
      $subject='CityUp - Reset your password';
      $message="You requested a CityUp password reset.\n\nOpen this link (valid for 30 minutes):\n".$url."\n\nIf this was not you, ignore this email.";
      try {
       require_once __DIR__.'/../Services/GmailResetMailer.php';
       GmailResetMailer::send($email,$subject,$message);
      } catch (Throwable $e) {
       error_log('CityUp password reset email failed: '.$e->getMessage());
      }
       
      $localHost=in_array(strtolower(explode(':',$host)[0]),['localhost','127.0.0.1','[::1]'],true);
      if ($localHost && getenv('CITYUP_DEV_RESET_LINK')==='1') $devLink=$url;
     }
    }
   }
  }
  $this->render('forgot_password',compact('errors','submitted','devLink')+['title'=>'CityUp | Forgot Password']);
 }

 public function reset(): void {
  $errors=[];$success=false;
  $token=(string)($_SERVER['REQUEST_METHOD']==='POST'?($_POST['token']??''):($_GET['token']??''));
  $valid=preg_match('/^[a-f0-9]{64}$/D',$token)===1;
  $row=null;
  if ($valid) {
   $q=$this->db->prepare('SELECT user_id FROM password_resets WHERE token_hash=:hash AND expires_at>NOW() LIMIT 1');
   $q->execute(['hash'=>hash('sha256',$token)]);$row=$q->fetch();
  }
  if ($_SERVER['REQUEST_METHOD']==='POST') {
   verifyCsrf();
   $password=(string)($_POST['password']??'');$confirm=(string)($_POST['password_confirm']??'');
   if (!$row) $errors[]='This reset link is invalid or has expired. Request a new one.';
   if (strlen($password)<8) $errors[]='Password must contain at least 8 characters.';
   if ($password!==$confirm) $errors[]='Passwords do not match.';
   if (!$errors) {
    $this->db->beginTransaction();
    try {
      
     $q=$this->db->prepare('SELECT user_id FROM password_resets WHERE token_hash=:hash AND expires_at>NOW() FOR UPDATE');
     $q->execute(['hash'=>hash('sha256',$token)]);$locked=$q->fetch();
     if (!$locked) { $this->db->rollBack();$errors[]='This reset link has already been used or expired.'; }
     else {
      $q=$this->db->prepare('UPDATE users SET password=:password WHERE id=:uid');
      $q->execute(['password'=>password_hash($password,PASSWORD_DEFAULT),'uid'=>(int)$locked['user_id']]);
      $q=$this->db->prepare('DELETE FROM password_resets WHERE user_id=:uid');
      $q->execute(['uid'=>(int)$locked['user_id']]);
      $this->db->commit();$success=true;
     }
    } catch(Throwable $e) {if($this->db->inTransaction())$this->db->rollBack();throw $e;}
   }
  }
  $canReset=(bool)$row && !$success;
  $this->render('reset_password',compact('errors','success','token','canReset')+['title'=>'CityUp | New Password']);
 }
}

<?php
class HomeController extends Controller {
 public function index(): void { $this->render('home',['title'=>'CityUp | Explore Your City','currentPage'=>'home']); }
 public function dashboard(): void {
   
  AuthController::requireRole('admin');
  $usersCount = null;
  try {
   $db = Database::getConnexion();
   $usersCount = (int) $db->query('SELECT COUNT(*) FROM users')->fetchColumn();
  } catch (PDOException $e) {
    
  }
  $this->render('dashboard',['title'=>'CityUp | Dashboard','currentPage'=>'dashboard','usersCount'=>$usersCount],true);
 }
}

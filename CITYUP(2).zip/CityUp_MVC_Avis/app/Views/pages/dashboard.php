<div class="dashboard-heading"><div><h1>Dashboard</h1><p>Welcome back, Admin! Here's an overview of City Up.</p></div><button class="date-select"><i class="fa-regular fa-calendar"></i> Last 30 Days <i class="fa-solid fa-chevron-down tiny"></i></button></div>
<section class="stats-grid" id="stats"><div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-store"></i></div><div><span>Businesses</span><strong>0</strong><small>No data yet</small></div></div><div class="stat-card"><div class="stat-icon blue"><i class="fa-regular fa-calendar-days"></i></div><div><span>Events</span><strong>0</strong><small>No data yet</small></div></div><div class="stat-card"><div class="stat-icon green"><i class="fa-solid fa-bicycle"></i></div><div><span>Activities</span><strong>0</strong><small>No data yet</small></div></div><div class="stat-card"><div class="stat-icon blue"><i class="fa-solid fa-users"></i></div><div><span>Users</span><strong id="cityup-users-count" aria-live="polite"><?= $usersCount === null ? "—" : (int)$usersCount ?></strong><small id="cityup-users-caption"><?= $usersCount === null ? "Database unavailable" : "Registered accounts" ?></small></div></div></section>
<div class="dashboard-layout"><div class="dashboard-primary"><div class="analytics-grid"><section class="panel activity-panel" id="activity"><div class="panel-heading"><h2>Platform Activity</h2><div class="legend"><span><em class="dot blue-dot"></em>Visits</span><span><em class="dot green-dot"></em>New Users</span></div></div><div class="line-chart"><div class="chart-empty">No activity recorded yet</div></div></section>
<section class="panel category-panel"><h2>Content by Category</h2><div class="donut-area"><div class="donut empty-donut"><div><strong>0</strong><span>Total Items</span></div></div><div class="category-legend"><span>Businesses  (0%)</span><span>Events  (0%)</span><span>Activities  (0%)</span><span>Urban Services  (0%)</span></div></div></section></div>
<div class="tables-grid"><section class="panel table-panel" id="recent"><div class="panel-heading"><h2><i class="fa-solid fa-store"></i> Recent Businesses</h2><a href="#recent">View All</a></div><table><thead><tr><th>Business Name</th><th>Category</th><th>Status</th><th>Date Added</th></tr></thead><tbody><tr><td class="no-records" colspan="4">No businesses added yet.</td></tr></tbody></table></section>
<section class="panel table-panel" id="events"><div class="panel-heading"><h2><i class="fa-regular fa-calendar-days"></i> Upcoming Events</h2><a href="#events">View All</a></div><table><thead><tr><th>Event</th><th>Date</th><th>Location</th></tr></thead><tbody><tr><td class="no-records" colspan="4">No events added yet.</td></tr></tbody></table></section></div></div>
<aside class="panel quick-actions" id="actions"><h2><i class="fa-solid fa-bolt"></i> Quick Actions</h2><button class="action-add" onclick="openAddModal('Business')"><i class="fa-solid fa-plus"></i> Add Business</button><button onclick="openAddModal('Event')"><i class="fa-solid fa-plus"></i> Add Event</button><button onclick="openAddModal('Activity')"><i class="fa-solid fa-plus"></i> Add Activity</button><button onclick="openAddModal('Urban Service')"><i class="fa-solid fa-landmark"></i> Add Urban Service</button><button onclick="openAddModal('Promotion')"><i class="fa-solid fa-plus"></i> Create Promotion</button></aside></div>

<section class="cu-dash-modules"><h2>City Up Management Modules</h2><p>Open the dedicated administration templates for each module.</p><a class="cu-action" href="index.php?page=modules&amp;area=admin">Manage modules <i class="fa-solid fa-arrow-right"></i></a></section>

<script>

(function () {
  const counter = document.getElementById('cityup-users-count');
  const caption = document.getElementById('cityup-users-caption');
  if (!counter || !caption) return;
  async function refreshUsers() {
    try {
      const response = await fetch('index.php?page=users-count', {cache: 'no-store', credentials: 'same-origin'});
      if (!response.ok) throw new Error('Database unavailable');
      const data = await response.json();
      if (!data.ok || !Number.isInteger(data.count)) throw new Error('Invalid response');
      counter.textContent = String(data.count);
      caption.textContent = 'Registered accounts';
    } catch (error) {
      counter.textContent = '—';
      caption.textContent = 'Database unavailable';
    }
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) refreshUsers();
  });
  window.addEventListener('focus', refreshUsers);
  window.setInterval(function () { if (!document.hidden) refreshUsers(); }, 10000);
})();
</script>

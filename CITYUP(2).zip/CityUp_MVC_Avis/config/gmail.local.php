<?php
 
return [
 'email' => 'YOUR_GMAIL@gmail.com',
 'app_password' => 'YOUR_APP_PASSWORD',
];
